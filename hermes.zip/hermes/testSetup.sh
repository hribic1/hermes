#!/bin/bash
echo 'setup permissions'
for core in {0..7}; do
	chmod 0666 /sys/devices/system/cpu/cpu${core}/cpufreq/scaling_setspeed
	chmod 0666 /sys/devices/system/cpu/cpu${core}/cpufreq/scaling_min_freq
	chmod 0666 /sys/devices/system/cpu/cpu${core}/cpufreq/scaling_max_freq
	chmod 0666 /sys/devices/system/cpu/cpu${core}/cpufreq/scaling_governor
	chmod 0666 /sys/devices/system/cpu/cpu${core}/cpufreq/cpuinfo_cur_freq
	echo ${core}
done

echo 'setup speed to 3600000'
for core in {0..7}; do
  echo 'userspace' > "/sys/devices/system/cpu/cpu${core}/cpufreq/scaling_governor"
  echo '3600000' > "/sys/devices/system/cpu/cpu${core}/cpufreq/scaling_setspeed"
done
