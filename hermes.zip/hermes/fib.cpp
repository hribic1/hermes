// filename: test_cilkplus.cpp  
// compile: g++4.8 fib.cpp -lcilkrts -ldl -fcilkplus
// compile: g++4.8 fib.cpp -o fib -lcilkrts -ldl -fcilkplus

//#include <unistd.h> // needed for sleep()
#include <ctime> // for execution time ex: clock_t clk = clock();

#include <stdio.h>  
//#include <unistd.h>  
#include <stdlib.h>
#include <iostream>
  
#include <cilk/cilk.h>  
#include <cilk/cilk_api.h>  

#include <unistd.h> // needed for sleep()
#include "example_util_gettime.h"

using namespace std;

int fib(int n, int k)
{
     //printf("********************** TASK: %d, WORKER ID: %d ********************** \n", n, k);
     if (n < 2)
	  return (n);
     else {
	  int x, y;
	  x = cilk_spawn fib(n - 1, __cilkrts_get_worker_number());
	  y = cilk_spawn fib(n - 2, __cilkrts_get_worker_number());
	  cilk_sync;
	  return (x + y);
     }
}

int main(int argc, char *argv[])
{
    long end;
    float par_time;
    float time_sum = 0;
    long start;
  
     int n, result;

     if (argc != 2) {
	  fprintf(stderr, "Usage: fib [<cilk options>] <n>\n");
	  return 0;
     }
     n = atoi(argv[1]);
     
    //cout << endl;
    //cout << "##### Begin sleep 10 seconds #####" << endl << endl;
    //int x = sleep(10);
    //if (x != 0) { cout << "ERROR: sleep(10) not NULL" << endl; }
    //cout << "End sleep: Begin timing in 2 seconds" << endl;
    //x = sleep(2);
    //if (x != 0) { cout << "ERROR: sleep(2) not NULL" << endl; } 
 
     //printf("######################################################################## \n");
     //cout << "Entry: " << __cilkrts_get_worker_number() << endl;
 
     int rpt = 1;
     for(int i = 0; i < rpt; i++)
     {
        start = example_get_time();
	
	result = cilk_spawn fib(n, __cilkrts_get_worker_number());
	cilk_sync;
	
	end = example_get_time();
	par_time = (end - start) / 1000.f;
	
	cout << "result = " << result << " single time = " << par_time << endl;;
	
	time_sum = time_sum + par_time;    
     }
     cout << "Execution time: " << time_sum/rpt << " seconds." << endl;
     
     return 0;
}

/*
 *result = 102334155 single time = 5.511
result = 102334155 single time = 5.696
result = 102334155 single time = 5.71
result = 102334155 single time = 5.634
result = 102334155 single time = 5.625
result = 102334155 single time = 5.615
result = 102334155 single time = 5.459
result = 102334155 single time = 5.693
result = 102334155 single time = 5.546
result = 102334155 single time = 5.473
result = 102334155 single time = 5.539
result = 102334155 single time = 5.51
result = 102334155 single time = 5.597
result = 102334155 single time = 5.604
result = 102334155 single time = 5.572
result = 102334155 single time = 5.568
result = 102334155 single time = 5.857
result = 102334155 single time = 5.868
result = 102334155 single time = 5.362
result = 102334155 single time = 5.675
Execution time: 5.6057 seconds.

 */